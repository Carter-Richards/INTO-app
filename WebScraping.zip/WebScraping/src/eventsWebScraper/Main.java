package eventsWebScraper;

import java.io.FileWriter;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.github.cliftonlabs.json_simple.JsonArray;
import com.github.cliftonlabs.json_simple.JsonObject;

public class Main {

	final static String eventsURL = "https://www.nusu.co.uk/whatson/";
	final static String[] htmlNames = {	"msl_eventlist",
										"msl_event_name",
										"msl_event_description",
										"msl_event_time",
										"msl_event_location",
										"msl_event_image"};
	
	public static void main(String[] args) {
		
		Elements daysWithEvents = new Elements();
		
		try {
			Document doc = Jsoup.connect(eventsURL).get();
			daysWithEvents = doc.getElementsByClass(htmlNames[0]).first().children();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
		JsonArray eventList = new JsonArray();
					
		for(Element e : daysWithEvents) {
			for(int i = 1; i < e.childrenSize(); i++) {
				eventList.add(getEventDetails(e.child(i)));
			}
		}
		printJsonToFile(eventList);
	}
	
	private static JsonObject getEventDetails(Element event) {
		JsonObject eventObject = new JsonObject();
		JsonObject eventDetails = new JsonObject();
		
		eventDetails.put("Name", event.getElementsByClass(htmlNames[1]).first().text());
		eventDetails.put("Description", event.getElementsByClass(htmlNames[2]).first().text());
		eventDetails.put("Time", event.getElementsByClass(htmlNames[3]).first().text());
		eventDetails.put("Location", event.getElementsByClass(htmlNames[4]).first().text());
		eventDetails.put("Img Src URL", event.getElementsByClass(htmlNames[5]).first().children().first().attr("abs:src"));
		
		eventObject.put("event", eventDetails);
		
		return eventObject;
	}
	
	private static void printJsonToFile(JsonArray eventList) {
		try {
			FileWriter file = new FileWriter("events.json");
			file.write(eventList.toJson());
			file.flush();
			file.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
}
